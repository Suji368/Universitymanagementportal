package UniversityManagementSystem;
import java.sql.*;
import java.util.Scanner;

public class UniversityManagementSysytemUITest {
    static final String URL = "jdbc:mysql://localhost:3306/university_portal_db";
//    jdbc:mysql://localhost:3306/
	    static final String USER = "root";  // your MySQL username
	    static final String PASSWORD = "root";  // your MySQL password

	    static Connection conn;
	    static Scanner sc = new Scanner(System.in);

	    public static void main(String[] args) {
	        try {
	            // Connect to MySQL
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            conn = DriverManager.getConnection(URL, USER, PASSWORD);
	            System.out.println("✅ Connected to University Management Database!");

	            while (true) {
	                System.out.println("\n===== UNIVERSITY MANAGEMENT PORTAL =====");
	                System.out.println("1. Add Student");
	                System.out.println("2. Add Faculty");
	                System.out.println("3. Add Course");
	                System.out.println("4. View Students");
	                System.out.println("5. View Courses");
	                System.out.println("6. Enroll Student in Course");
	                System.out.println("7. View Enrollments");
	                System.out.println("8. Exit");
	                System.out.print("Enter choice: ");
	                int choice = sc.nextInt();

	                switch (choice) {
	                    case 1 -> addStudent();
	                    case 2 -> addFaculty();
	                    case 3 -> addCourse();
	                    case 4 -> viewStudents();
	                    case 5 -> viewCourses();
	                    case 6 -> enrollStudent();
	                    case 7 -> viewEnrollments();
	                    case 8 -> {
	                        System.out.println("👋 Exiting system. Goodbye!");
	                        conn.close();
	                        System.exit(0);
	                    }
	                    default -> System.out.println("❌ Invalid choice! Try again.");
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 1️⃣ Add Student
	    static void addStudent() {
	        try {
	            sc.nextLine();
	            System.out.print("Enter student name: ");
	            String name = sc.nextLine();
	            System.out.print("Enter student email: ");
	            String email = sc.nextLine();
	            System.out.print("Enter department: ");
	            String department = sc.nextLine();

	            String query = "INSERT INTO students(name, email, department) VALUES(?, ?, ?)";
	            PreparedStatement pst = conn.prepareStatement(query);
	            pst.setString(1, name);
	            pst.setString(2, email);
	            pst.setString(3, department);
	            pst.executeUpdate();

	            System.out.println("🎓 Student added successfully!");
	        } catch (SQLIntegrityConstraintViolationException e) {
	            System.out.println("⚠️ Email already exists!");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 2️⃣ Add Faculty
	    static void addFaculty() {
	        try {
	            sc.nextLine();
	            System.out.print("Enter faculty name: ");
	            System.out.print("Enter faculty email: ");
	            String name = sc.nextLine();
	            String email = sc.nextLine();
	            System.out.print("Enter department: ");
	            String department = sc.nextLine();

	            String query = "INSERT INTO faculty(name, email, department) VALUES(?, ?, ?)";
	            PreparedStatement pst = conn.prepareStatement(query);
	            pst.setString(1, name);
	            pst.setString(2, email);
	            pst.setString(3, department);
	            pst.executeUpdate();

	            System.out.println("👨‍🏫 Faculty added successfully!");
	        } catch (SQLIntegrityConstraintViolationException e) {
	            System.out.println("⚠️ Email already exists!");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 3️⃣ Add Course
	    static void addCourse() {
	        try {
	            System.out.println("\n--- Available Faculty ---");
	            Statement st = conn.createStatement();
	            ResultSet rs = st.executeQuery("SELECT * FROM faculty");
	            while (rs.next()) {
	                System.out.println(rs.getInt("faculty_id") + " | " + rs.getString("name") + " (" + rs.getString("department") + ")");
	            }

	            sc.nextLine();
	            System.out.print("\nEnter course name: ");
	            String name = sc.nextLine();
	            System.out.print("Enter credits: ");
	            int credits = sc.nextInt();
	            System.out.print("Enter faculty ID: ");
	            int facultyId = sc.nextInt();

	            String query = "INSERT INTO courses(course_name, credits, faculty_id) VALUES(?, ?, ?)";
	            PreparedStatement pst = conn.prepareStatement(query);
	            pst.setString(1, name);
	            pst.setInt(2, credits);
	            pst.setInt(3, facultyId);
	            pst.executeUpdate();

	            System.out.println("📘 Course added successfully!");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 4️⃣ View Students
	    static void viewStudents() {
	        try {
	            String query = "SELECT * FROM students";
	            Statement st = conn.createStatement();
	            ResultSet rs = st.executeQuery(query);

	            System.out.println("\n--- Student List ---");
	            while (rs.next()) {
	                System.out.println("ID: " + rs.getInt("student_id") +
	                        " | Name: " + rs.getString("name") +
	                        " | Email: " + rs.getString("email") +
	                        " | Dept: " + rs.getString("department"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 5️⃣ View Courses
	    static void viewCourses() {
	        try {
	            String query = """
	                SELECT c.course_id, c.course_name, c.credits, f.name AS faculty
	                FROM courses c
	                LEFT JOIN faculty f ON c.faculty_id = f.faculty_id
	            """;
	            Statement st = conn.createStatement();
	            ResultSet rs = st.executeQuery(query);

	            System.out.println("\n--- Course List ---");
	            while (rs.next()) {
	                System.out.println("ID: " + rs.getInt("course_id") +
	                        " | Course: " + rs.getString("course_name") +
	                        " | Credits: " + rs.getInt("credits") +
	                        " | Faculty: " + rs.getString("faculty"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 6️⃣ Enroll Student in Course
	    static void enrollStudent() {
	        try {
	            System.out.println("\n--- Students ---");
	            Statement st1 = conn.createStatement();
	            ResultSet rs1 = st1.executeQuery("SELECT * FROM students");
	            while (rs1.next()) {
	                System.out.println(rs1.getInt("student_id") + " | " + rs1.getString("name"));
	            }

	            System.out.println("\n--- Courses ---");
	            Statement st2 = conn.createStatement();
	            ResultSet rs2 = st2.executeQuery("SELECT * FROM courses");
	            while (rs2.next()) {
	                System.out.println(rs2.getInt("course_id") + " | " + rs2.getString("course_name"));
	            }

	            System.out.print("\nEnter student ID: ");
	            int studentId = sc.nextInt();
	            System.out.print("Enter course ID: ");
	            int courseId = sc.nextInt();

	            String query = "INSERT INTO enrollments(student_id, course_id) VALUES(?, ?)";
	            PreparedStatement pst = conn.prepareStatement(query);
	            pst.setInt(1, studentId);
	            pst.setInt(2, courseId);
	            pst.executeUpdate();

	            System.out.println("✅ Student successfully enrolled in course!");
	        } catch (SQLIntegrityConstraintViolationException e) {
	            System.out.println("⚠️ Invalid student or course ID!");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 7️⃣ View Enrollments
	    static void viewEnrollments() {
	        try {
	            String query = """
	                SELECT e.enrollment_id, s.name AS student, s.department, c.course_name, f.name AS faculty, e.enrollment_date
	                FROM enrollments e
	                JOIN students s ON e.student_id = s.student_id
	                JOIN courses c ON e.course_id = c.course_id
	                LEFT JOIN faculty f ON c.faculty_id = f.faculty_id
	                ORDER BY e.enrollment_date DESC
	            """;
	            Statement st = conn.createStatement();
	            ResultSet rs = st.executeQuery(query);

	            System.out.println("\n--- Enrollments ---");
	            while (rs.next()) {
	                System.out.println("Enrollment ID: " + rs.getInt("enrollment_id") +
	                        " | Student: " + rs.getString("student") +
	                        " (" + rs.getString("department") + ")" +
	                        " | Course: " + rs.getString("course_name") +
	                        " | Faculty: " + rs.getString("faculty") +
	                        " | Date: " + rs.getTimestamp("enrollment_date"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}
