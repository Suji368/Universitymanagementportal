package transport_management_system;

import java.sql.*;
import java.util.Scanner;

public class Vehicle {

    public static void addVehicle() {
        try {
            Connection con = DBConnection.getConnection();
            Scanner sc = new Scanner(System.in);

            System.out.print("Vehicle No: ");
            String no = sc.nextLine();
            System.out.print("Vehicle Type: ");
            String type = sc.nextLine();
            System.out.print("Capacity: ");
            int cap = sc.nextInt();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO vehicles(vehicle_no, vehicle_type, capacity, status) VALUES(?,?,?,?)"
            );
            ps.setString(1, no);
            ps.setString(2, type);
            ps.setInt(3, cap);
            ps.setString(4, "Available");

            ps.executeUpdate();
            System.out.println("Vehicle Added Successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void viewVehicles() {
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM vehicles");

            System.out.println("\nVEHICLE LIST:");
            while (rs.next()) {
                System.out.println(
                    rs.getInt("vehicle_id") + " | " +
                    rs.getString("vehicle_no") + " | " +
                    rs.getString("vehicle_type") + " | " +
                    rs.getInt("capacity") + " | " +
                    rs.getString("status")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

