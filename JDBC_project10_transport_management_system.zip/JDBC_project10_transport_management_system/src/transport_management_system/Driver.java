package transport_management_system;

import java.sql.*;
import java.util.Scanner;

public class Driver {

    public static void addDriver() {
        try {
            Connection con = DBConnection.getConnection();
            Scanner sc = new Scanner(System.in);

            System.out.print("Driver Name: ");
            String name = sc.nextLine();
            System.out.print("License No: ");
            String lic = sc.nextLine();
            System.out.print("Phone: ");
            String phone = sc.nextLine();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO drivers(name, license_no, phone) VALUES(?,?,?)"
            );
            ps.setString(1, name);
            ps.setString(2, lic);
            ps.setString(3, phone);

            ps.executeUpdate();
            System.out.println("Driver Added Successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void viewDrivers() {
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM drivers");

            System.out.println("\nDRIVER LIST:");
            while (rs.next()) {
                System.out.println(
                    rs.getInt("driver_id") + " | " +
                    rs.getString("name") + " | " +
                    rs.getString("license_no") + " | " +
                    rs.getString("phone")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
