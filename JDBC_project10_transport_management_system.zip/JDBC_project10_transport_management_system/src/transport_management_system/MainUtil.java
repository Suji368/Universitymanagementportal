package transport_management_system;

import java.util.Scanner;

public class MainUtil {
	
    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        while (true) {
	            System.out.println("\nTRANSPORT MANAGEMENT SYSTEM");
	            System.out.println("1. Add Vehicle");
	            System.out.println("2. View Vehicles");
	            System.out.println("3. Add Driver");
	            System.out.println("4. View Drivers");
	            System.out.println("5. Assign Trip");
	            System.out.println("6. View Trips");
	            System.out.println("7. Exit");

	            System.out.print("Enter Choice: ");
	            int ch = sc.nextInt();

	            switch (ch) {
	                case 1: Vehicle.addVehicle(); break;
	                case 2: Vehicle.viewVehicles(); break;
	                case 3: Driver.addDriver(); break;
	                case 4: Driver.viewDrivers(); break;
	                case 5: Trip.assignTrip(); break;
	                case 6: Trip.viewTrips(); break;
	                case 7: System.exit(0);
	                default: System.out.println("Invalid Choice!");
	            }
	        }
	    }
	}
