package transport_management_system;

import java.sql.*;
import java.util.Scanner;

public class Trip {

    public static void assignTrip() {
        try {
            Connection con = DBConnection.getConnection();
            Scanner sc = new Scanner(System.in);

            System.out.print("Vehicle ID: ");
            int vid = sc.nextInt();
            System.out.print("Driver ID: ");
            int did = sc.nextInt();
            sc.nextLine();

            System.out.print("Source: ");
            String src = sc.nextLine();
            System.out.print("Destination: ");
            String dest = sc.nextLine();
            System.out.print("Trip Date (YYYY-MM-DD): ");
            String date = sc.nextLine();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO trips(vehicle_id, driver_id, source, destination, trip_date) VALUES(?,?,?,?,?)"
            );
            ps.setInt(1, vid);
            ps.setInt(2, did);
            ps.setString(3, src);
            ps.setString(4, dest);
            ps.setDate(5, Date.valueOf(date));

            ps.executeUpdate();

            PreparedStatement update = con.prepareStatement(
                "UPDATE vehicles SET status='On Trip' WHERE vehicle_id=?"
            );
            update.setInt(1, vid);
            update.executeUpdate();

            System.out.println("Trip Assigned Successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void viewTrips() {
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM trips");

            System.out.println("\nTRIP DETAILS:");
            while (rs.next()) {
                System.out.println(
                    rs.getInt("trip_id") + " | Vehicle: " +
                    rs.getInt("vehicle_id") + " | Driver: " +
                    rs.getInt("driver_id") + " | " +
                    rs.getString("source") + " -> " +
                    rs.getString("destination") + " | " +
                    rs.getDate("trip_date")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
