package Online_Course_Registration_service;

import Online_Course_Registration_DAO.CourseDAO;
import Online_Course_Registration_DAO.StudentDAO;
import Online_Course_Registration_model.Course;
import Online_Course_Registration_model.Student;

public class CourseService {

    CourseDAO courseDAO = new CourseDAO();
    StudentDAO studentDAO = new StudentDAO();

    public void addCourse(int id, String name, int duration) {

        if(duration <= 0){
            System.out.println("Duration must be greater than 0");
            return;
        }

        Course course = new Course(id, name, duration);
        courseDAO.addCourse(course);
    }

    public void registerStudent(int sid, String name, int courseId) {

        if(name == null || name.isEmpty()){
            System.out.println("Student name cannot be empty");
            return;
        }

        Student student = new Student(sid, name, courseId);
        studentDAO.registerStudent(student);
    }
}