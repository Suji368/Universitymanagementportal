package Online_Course_Registration_DAO;

import java.sql.*;

import Online_Course_Registration_model.Student;
import db_connection.DBConnection;

public class StudentDAO {

    public void registerStudent(Student student) {

        try {

            Connection conn = DBConnection.getConnection();

            String sql = "INSERT INTO student VALUES(?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, student.getStudentId());
            ps.setString(2, student.getStudentName());
            ps.setInt(3, student.getCourseId());

            ps.executeUpdate();

            System.out.println("Student Registered Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}