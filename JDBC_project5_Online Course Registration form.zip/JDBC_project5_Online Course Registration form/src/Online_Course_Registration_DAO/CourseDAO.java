package Online_Course_Registration_DAO;

import java.sql.*;

import Online_Course_Registration_model.Course;
import db_connection.DBConnection;

public class CourseDAO {

    public void addCourse(Course course) {

        try {

            Connection conn = DBConnection.getConnection();

            String sql = "INSERT INTO course VALUES(?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, course.getCourseId());
            ps.setString(2, course.getCourseName());
            ps.setInt(3, course.getDuration());

            ps.executeUpdate();

            System.out.println("Course Added Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
