package main_test;

import java.util.Scanner;
import Online_Course_Registration_controller.CourseController;

public class MainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        CourseController controller = new CourseController();

        while(true){

            System.out.println("\n--- Online Course Registration System ---");
            System.out.println("1. Add Course");
            System.out.println("2. Register Student");
            System.out.println("3. Exit");

            int choice = sc.nextInt();

            switch(choice){

                case 1:

                    System.out.print("Course ID: ");
                    int cid = sc.nextInt();

                    System.out.print("Course Name: ");
                    String cname = sc.next();

                    System.out.print("Duration (months): ");
                    int dur = sc.nextInt();

                    controller.addCourse(cid,cname,dur);
                    break;

                case 2:

                    System.out.print("Student ID: ");
                    int sid = sc.nextInt();

                    System.out.print("Student Name: ");
                    String sname = sc.next();

                    System.out.print("Course ID: ");
                    int courseId = sc.nextInt();

                    controller.registerStudent(sid,sname,courseId);
                    break;

                case 3:
                    System.exit(0);
            }
        }
    }
}