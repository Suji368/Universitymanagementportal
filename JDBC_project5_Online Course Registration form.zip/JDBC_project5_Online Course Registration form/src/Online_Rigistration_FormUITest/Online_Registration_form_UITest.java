package Online_Rigistration_FormUITest;
import java.sql.*;
import java.util.Scanner;

public class Online_Registration_form_UITest {

	    static final String URL = "jdbc:mysql://localhost:3306/course_registration_db";
	    static final String USER = "root"; // your MySQL username
	    static final String PASSWORD = "root"; // your MySQL password

	    static Connection conn;
	    static Scanner sc = new Scanner(System.in);

	    public static void main(String[] args) {
	        try {
	            // Connect to MySQL
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            conn = DriverManager.getConnection(URL, USER, PASSWORD);
	            System.out.println("✅ Connected to Course Registration Database!");

	            while (true) {
	                System.out.println("\n===== ONLINE COURSE REGISTRATION SYSTEM =====");
	                System.out.println("1. Add New Student");
	                System.out.println("2. Add New Course");
	                System.out.println("3. View All Students");
	                System.out.println("4. View All Courses");
	                System.out.println("5. Register Student for a Course");
	                System.out.println("6. View Course Registrations");
	                System.out.println("7. Exit");
	                System.out.print("Enter your choice: ");
	                int choice = sc.nextInt();

	                switch (choice) {
	                    case 1 -> addStudent();
	                    case 2 -> addCourse();
	                    case 3 -> viewStudents();
	                    case 4 -> viewCourses();
	                    case 5 -> registerCourse();
	                    case 6 -> viewRegistrations();
	                    case 7 -> {
	                        System.out.println("👋 Exiting system. Goodbye!");
	                        conn.close();
	                        System.exit(0);
	                    }
	                    default -> System.out.println("❌ Invalid choice! Try again.");
	                }
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 1️⃣ Add new student
	    static void addStudent() {
	        try {
	            sc.nextLine(); // clear buffer
	            System.out.print("Enter student name: ");
	            String name = sc.nextLine();
	            System.out.print("Enter email: ");
	            String email = sc.nextLine();

	            String query = "INSERT INTO students(name, email) VALUES(?, ?)";
	            PreparedStatement pst = conn.prepareStatement(query);
	            pst.setString(1, name);
	            pst.setString(2, email);
	            pst.executeUpdate();

	            System.out.println("🎓 Student added successfully!");
	        } catch (SQLIntegrityConstraintViolationException e) {
	            System.out.println("⚠️ Email already exists! Please use a different email.");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 2️⃣ Add new course
	    static void addCourse() {
	        try {
	            sc.nextLine();
	            System.out.print("Enter course name: ");
	            String courseName = sc.nextLine();
	            System.out.print("Enter instructor name: ");
	            String instructor = sc.nextLine();
	            System.out.print("Enter available seats: ");
	            int seats = sc.nextInt();

	            String query = "INSERT INTO courses(course_name, instructor, seats_available) VALUES(?, ?, ?)";
	            PreparedStatement pst = conn.prepareStatement(query);
	            pst.setString(1, courseName);
	            pst.setString(2, instructor);
	            pst.setInt(3, seats);
	            pst.executeUpdate();

	            System.out.println("📘 Course added successfully!");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 3️⃣ View all students
	    static void viewStudents() {
	        try {
	            String query = "SELECT * FROM students";
	            Statement st = conn.createStatement();
	            ResultSet rs = st.executeQuery(query);

	            System.out.println("\n--- Student List ---");
	            while (rs.next()) {
	                System.out.println("ID: " + rs.getInt("student_id") +
	                        " | Name: " + rs.getString("name") +
	                        " | Email: " + rs.getString("email"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 4️⃣ View all courses
	    static void viewCourses() {
	        try {
	            String query = "SELECT * FROM courses";
	            Statement st = conn.createStatement();
	            ResultSet rs = st.executeQuery(query);

	            System.out.println("\n--- Course List ---");
	            while (rs.next()) {
	                System.out.println("ID: " + rs.getInt("course_id") +
	                        " | Course: " + rs.getString("course_name") +
	                        " | Instructor: " + rs.getString("instructor") +
	                        " | Seats Available: " + rs.getInt("seats_available"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 5️⃣ Register student for a course
	    static void registerCourse() {
	        try {
	            System.out.print("Enter student ID: ");
	            int studentId = sc.nextInt();
	            System.out.print("Enter course ID: ");
	            int courseId = sc.nextInt();

	            // Check if course has available seats
	            String checkSeats = "SELECT seats_available FROM courses WHERE course_id = ?";
	            PreparedStatement seatPst = conn.prepareStatement(checkSeats);
	            seatPst.setInt(1, courseId);
	            ResultSet rs = seatPst.executeQuery();

	            if (rs.next()) {
	                int availableSeats = rs.getInt("seats_available");
	                if (availableSeats > 0) {
	                    // Register the student
	                    String registerQuery = "INSERT INTO registrations(student_id, course_id) VALUES(?, ?)";
	                    PreparedStatement regPst = conn.prepareStatement(registerQuery);
	                    regPst.setInt(1, studentId);
	                    regPst.setInt(2, courseId);
	                    regPst.executeUpdate();

	                    // Update seat count
	                    String updateSeats = "UPDATE courses SET seats_available = seats_available - 1 WHERE course_id = ?";
	                    PreparedStatement updatePst = conn.prepareStatement(updateSeats);
	                    updatePst.setInt(1, courseId);
	                    updatePst.executeUpdate();

	                    System.out.println("✅ Student successfully registered for the course!");
	                } else {
	                    System.out.println("⚠️ No seats available for this course.");
	                }
	            } else {
	                System.out.println("❌ Course not found!");
	            }
	        } catch (SQLIntegrityConstraintViolationException e) {
	            System.out.println("⚠️ Invalid student or course ID!");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // 6️⃣ View course registrations
	    static void viewRegistrations() {
	        try {
	            String query = """
	                    SELECT r.registration_id, s.name AS student, s.email, c.course_name, c.instructor, r.registration_date
	                    FROM registrations r
	                    JOIN students s ON r.student_id = s.student_id
	                    JOIN courses c ON r.course_id = c.course_id
	                    ORDER BY r.registration_date DESC
	                    """;
	            Statement st = conn.createStatement();
	            ResultSet rs = st.executeQuery(query);

	            System.out.println("\n--- Course Registrations ---");
	            while (rs.next()) {
	                System.out.println("Registration ID: " + rs.getInt("registration_id") +
	                        " | Student: " + rs.getString("student") +
	                        " (" + rs.getString("email") + ")" +
	                        " | Course: " + rs.getString("course_name") +
	                        " | Instructor: " + rs.getString("instructor") +
	                        " | Date: " + rs.getTimestamp("registration_date"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	


}
