package Online_Course_Registration_controller;

import Online_Course_Registration_service.CourseService;

public class CourseController {

    CourseService service = new CourseService();

    public void addCourse(int id, String name, int duration) {

        service.addCourse(id, name, duration);
    }

    public void registerStudent(int sid, String name, int courseId) {

        service.registerStudent(sid, name, courseId);
    }
}
