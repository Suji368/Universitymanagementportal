package college_Admission_UITest;

import java.sql.SQLException;
import java.util.Scanner;

import college_Admission_DAO.AdminDAO;
import college_Admission_DAO.CourseDAO;
import college_Admission_DAO.EnrollmentDAO;
import college_Admission_DAO.StudentDAO;

public class UITest {

	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);

        System.out.println("===== College Admission System =====");
        System.out.print("Enter Admin Username: ");
        String user = sc.nextLine();
        System.out.print("Enter Password: ");
        String pass = sc.nextLine();

        if (!AdminDAO.login(user, pass)) {
            System.out.println("❌ Invalid login. Exiting...");
        }

//        System.out.println("✅ Login successful! Welcome, " + user);

        while (true) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Add Course");
            System.out.println("4. View Courses");
            System.out.println("5. Enroll Student");
            System.out.println("6. View Enrollments");
            System.out.println("7. Logout");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter DOB (YYYY-MM-DD): ");
                    String dob = sc.nextLine();
                    System.out.print("Enter Email: ");
                    String email = sc.nextLine();
                    StudentDAO.addStudent(name, dob, email);
                    break;

                case 2:
                    StudentDAO.viewStudents();
                    break;

                case 3:
                    System.out.print("Enter Course Name: ");
                    String cname = sc.nextLine();
                    System.out.print("Enter Duration: ");
                    String duration = sc.nextLine();
                    System.out.print("Enter Fees: ");
                    double fees = sc.nextDouble();
                    CourseDAO.addCourse(cname, duration, fees);
                    break;

                case 4:
                    CourseDAO.viewCourses();
                    break;

                case 5:
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt();
                    System.out.print("Enter Course ID: ");
                    int cid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Date (YYYY-MM-DD): ");
                    String date = sc.nextLine();
                    EnrollmentDAO.enrollStudent(sid, cid, date);
                    break;

                case 6:
                    EnrollmentDAO.viewEnrollments();
                    break;

                case 7:
                    System.out.println("👋 Logged out. Goodbye!");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice!");
            }
        }
	}

}