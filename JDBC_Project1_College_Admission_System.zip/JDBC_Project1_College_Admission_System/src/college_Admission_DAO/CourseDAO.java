package college_Admission_DAO;

import java.sql.Connection;
import java.sql.*;
import java.sql.Statement;

import college_Admission_db_connection.DB_Connection;

public class CourseDAO {
	public static void addCourse(String name, String duration, double fees) {
        try (Connection con = DB_Connection.getDBConnection()) {
            String query = "INSERT INTO course(course_name, duration, fees) VALUES(?,?,?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, duration);
            ps.setDouble(3, fees);
            ps.executeUpdate();
            System.out.println("✅ Course added successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void viewCourses() {
        try (Connection con = DB_Connection.getDBConnection()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM course");
            System.out.println("\n--- Course List ---");
            while (rs.next()) {
                System.out.println(rs.getInt("course_id") + " | " +
                        rs.getString("course_name") + " | " +
                        rs.getString("duration") + " | " +
                        rs.getDouble("fees"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
