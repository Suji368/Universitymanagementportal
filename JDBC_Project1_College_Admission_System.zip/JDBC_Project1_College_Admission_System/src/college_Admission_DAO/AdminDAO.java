package college_Admission_DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import college_Admission_db_connection.DB_Connection;

public class AdminDAO {
	
		public static boolean login(String username, String password) throws SQLException {
			boolean status = false;
			try(Connection con = DB_Connection.getDBConnection();){
		String query = "select * from admin where username=? AND password=?";
					PreparedStatement ps = con.prepareStatement(query);
					ps.setString(1,username);
					ps.setString(2,password);
					
				ResultSet rs =	ps.executeQuery();
						status = rs.next();
				if(status) {
					System.out.println("✅ Login successful! Welcome: "+username);
				}
				return status;
			}
		}
}
