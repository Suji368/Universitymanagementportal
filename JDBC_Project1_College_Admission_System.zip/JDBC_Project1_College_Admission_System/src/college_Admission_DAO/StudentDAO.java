package college_Admission_DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import college_Admission_db_connection.DB_Connection;

public class StudentDAO {
	public static void addStudent(String name, String dob, String email) {
		try (Connection con = DB_Connection.getDBConnection()) {
			String query = "INSERT INTO student(name, dob, email) VALUES(?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, name);
			ps.setString(2, dob);
			ps.setString(3, email);
			ps.executeUpdate();
			System.out.println("✅ Student added successfully!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void viewStudents() {
		try (Connection con = DB_Connection.getDBConnection()) {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM student");
			System.out.println("\n--- Student List ---");
			while (rs.next()) {
				System.out.println(rs.getInt("student_id") + " | " + rs.getString("name") + " | " + rs.getString("dob")
						+ " | " + rs.getString("email"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
