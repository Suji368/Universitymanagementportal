package college_Admission_DAO;

import java.sql.*;

import college_Admission_db_connection.DB_Connection;

public class EnrollmentDAO {
	 public static void enrollStudent(int studentId, int courseId, String date) {
	        try (Connection con = DB_Connection.getDBConnection()) {
	            String query = "INSERT INTO enrollment(student_id, course_id, date_enrolled) VALUES(?,?,?)";
	            PreparedStatement ps = con.prepareStatement(query);
	            ps.setInt(1, studentId);
	            ps.setInt(2, courseId);
	            ps.setString(3, date);
	            ps.executeUpdate();
	            System.out.println("✅ Student enrolled successfully!");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public static void viewEnrollments() {
	        try (Connection con = DB_Connection.getDBConnection()) {
	            String query = "SELECT e.enrollment_id, s.name, c.course_name, e.date_enrolled " +
	                    "FROM enrollment e JOIN student s ON e.student_id=s.student_id " +
	                    "JOIN course c ON e.course_id=c.course_id";
	            Statement st = con.createStatement();
	            ResultSet rs = st.executeQuery(query);
	            System.out.println("\n--- Enrollments ---");
	            while (rs.next()) {
	                System.out.println(rs.getInt("enrollment_id") + " | " +
	                        rs.getString("name") + " | " +
	                        rs.getString("course_name") + " | " +
	                        rs.getString("date_enrolled"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
}
