package college_Admission_db_connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB_Connection {
	private static Connection con;
	public static Connection getDBConnection()  {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"
					+ "student_enrollment", "root", "root");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}
