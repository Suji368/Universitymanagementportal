package entity;

public class Student {
	private String name;
	private String DAO;
	private String email;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDAO() {
		return DAO;
	}
	public void setDAO(String dAO) {
		DAO = dAO;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
