package Online_Exam_Management_controller;

import Online_Exam_Management_service.UserService;

public class UserController {

    private UserService userService = new UserService();

    public void register(String name,String email,String password){

        userService.registerUser(name,email,password,"STUDENT");

        System.out.println("User Registered Successfully");
    }
}