package main;

import Online_Exam_Management_controller.UserController;

public class Main {

    public static void main(String[] args) {

        UserController controller = new UserController();

        controller.register(
                "John",
                "john@gmail.com",
                "12345"
        );
    }
}