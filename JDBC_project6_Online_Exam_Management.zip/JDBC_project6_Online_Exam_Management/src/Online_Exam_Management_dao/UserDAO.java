package Online_Exam_Management_dao;

import java.sql.*;

import Online_Exam_Management_model.User;

public class UserDAO {

    public void addUser(User user){
        try{
            Connection con = DBConnection.getConnection();
            String sql="INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)";

            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1,user.getName());
            ps.setString(2,user.getEmail());
            ps.setString(3,user.getPassword());
            ps.setString(4,user.getRole());

            ps.executeUpdate();
            con.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}