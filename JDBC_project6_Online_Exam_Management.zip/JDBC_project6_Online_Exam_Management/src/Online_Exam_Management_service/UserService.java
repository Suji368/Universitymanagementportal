package Online_Exam_Management_service;

import Online_Exam_Management_dao.UserDAO;
import Online_Exam_Management_model.User;

public class UserService {

    private UserDAO userDAO = new UserDAO();

    public void registerUser(String name,String email,String password,String role){

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);

        userDAO.addUser(user);
    }
}