package airlines_reservation_main;

import java.util.Scanner;

import airlines_reservation_controller.AirlineController;

public class MainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        AirlineController controller = new AirlineController();

        while(true) {

            System.out.println("\n--- Airline Reservation System ---");
            System.out.println("1. Add Flight");
            System.out.println("2. Book Ticket");
            System.out.println("3. Exit");

            int choice = sc.nextInt();

            switch(choice) {

                case 1:
                    System.out.print("Flight ID: ");
                    int id = sc.nextInt();

                    System.out.print("Flight Name: ");
                    String name = sc.next();

                    System.out.print("Source: ");
                    String src = sc.next();

                    System.out.print("Destination: ");
                    String dest = sc.next();

                    System.out.print("Seats: ");
                    int seats = sc.nextInt();

                    controller.addFlight(id,name,src,dest,seats);
                    break;

                case 2:
                    System.out.print("Passenger ID: ");
                    int pid = sc.nextInt();

                    System.out.print("Passenger Name: ");
                    String pname = sc.next();

                    System.out.print("Flight ID: ");
                    int fid = sc.nextInt();

                    controller.bookTicket(pid,pname,fid);
                    break;

                case 3:
                    System.exit(0);
            }
        }
    }
}