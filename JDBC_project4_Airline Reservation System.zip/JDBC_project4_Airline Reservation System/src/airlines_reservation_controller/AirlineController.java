package airlines_reservation_controller;

import airlines_reservation_service.AirlineService;

public class AirlineController {

    AirlineService service = new AirlineService();

    public void addFlight(int id, String name, String source, String dest, int seats){

        service.addFlight(id, name, source, dest, seats);
    }

    public void bookTicket(int pid, String name, int flightId){

        service.bookTicket(pid, name, flightId);
    }
}
