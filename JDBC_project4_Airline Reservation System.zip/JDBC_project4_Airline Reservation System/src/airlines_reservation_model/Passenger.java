package airlines_reservation_model;


public class Passenger {

    private int passengerId;
    private String name;
    private int flightId;

    public Passenger(){}

    public Passenger(int passengerId, String name, int flightId) {
        this.passengerId = passengerId;
        this.name = name;
        this.flightId = flightId;
    }

    public int getPassengerId() {
        return passengerId;
    }

    public void setPassengerId(int passengerId) {
        this.passengerId = passengerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFlightId() {
        return flightId;
    }

    public void setFlightId(int flightId) {
        this.flightId = flightId;
    }
}