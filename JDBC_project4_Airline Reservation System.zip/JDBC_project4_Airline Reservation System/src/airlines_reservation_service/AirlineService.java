package airlines_reservation_service;

import airlines_reservation_DAO.FlightDAO;
import airlines_reservation_DAO.PassengerDAO;
import airlines_reservation_model.Flight;
import airlines_reservation_model.Passenger;

public class AirlineService {

    FlightDAO flightDAO = new FlightDAO();
    PassengerDAO passengerDAO = new PassengerDAO();

    public void addFlight(int id, String name, String source, String dest, int seats) {

        if(seats <= 0){
            System.out.println("Seats must be greater than 0");
            return;
        }

        Flight flight = new Flight(id, name, source, dest, seats);
        flightDAO.addFlight(flight);
    }

    public void bookTicket(int pid, String pname, int flightId){

        if(pname == null || pname.isEmpty()){
            System.out.println("Passenger name cannot be empty");
            return;
        }

        Passenger passenger = new Passenger(pid, pname, flightId);
        passengerDAO.bookTicket(passenger);
    }
}