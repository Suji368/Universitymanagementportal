package airlines_reservation_DAO;


import java.sql.*;

import airlines_reservation_model.Passenger;
import db_connection.DBConnection;

public class PassengerDAO {

    public void bookTicket(Passenger passenger) {

        try {
            Connection conn = DBConnection.getConnection();

            String sql = "INSERT INTO passenger VALUES(?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, passenger.getPassengerId());
            ps.setString(2, passenger.getName());
            ps.setInt(3, passenger.getFlightId());

            ps.executeUpdate();

            System.out.println("Ticket Booked Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}