package airlines_reservation_DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

import airlines_reservation_model.Flight;
import db_connection.DBConnection;



public class FlightDAO {

    public void addFlight(Flight flight) {

        try {
            Connection conn = DBConnection.getConnection();

            String sql = "INSERT INTO flight VALUES(?,?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, flight.getFlightId());
            ps.setString(2, flight.getFlightName());
            ps.setString(3, flight.getSource());
            ps.setString(4, flight.getDestination());
            ps.setInt(5, flight.getSeats());

            ps.executeUpdate();

            System.out.println("Flight Added Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}