package online_voting;

import java.sql.*;
import java.util.Scanner;

public class Register {
    public static void registerUser() {
        try {
            Connection con = DBConnection.getConnection();
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter Username: ");
            String username = sc.next();

            System.out.print("Enter Password: ");
            String password = sc.next();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO users(username, password) VALUES(?, ?)"
            );
            ps.setString(1, username);
            ps.setString(2, password);

            ps.executeUpdate();
            System.out.println("Registration Successful!");

        } catch (Exception e) {
            System.out.println("Username already exists!");
        }
    }
}

