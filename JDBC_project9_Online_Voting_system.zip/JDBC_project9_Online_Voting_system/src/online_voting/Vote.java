package online_voting;

import java.sql.*;
import java.util.Scanner;

public class Vote {
    public static void vote() {
        try {
            Connection con = DBConnection.getConnection();
            Scanner sc = new Scanner(System.in);

            System.out.print("Username: ");
            String username = sc.next();
            System.out.print("Password: ");
            String password = sc.next();

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM users WHERE username=? AND password=?"
            );
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                if (rs.getBoolean("has_voted")) {
                    System.out.println("You have already voted!");
                    return;
                }

                Statement st = con.createStatement();
                ResultSet crs = st.executeQuery("SELECT * FROM candidates");

                System.out.println("\nCandidates:");
                while (crs.next()) {
                    System.out.println(
                        crs.getInt("candidate_id") + ". " +
                        crs.getString("name")
                    );
                }

                System.out.print("Enter Candidate ID to vote: ");
                int cid = sc.nextInt();

                PreparedStatement votePs = con.prepareStatement(
                    "UPDATE candidates SET votes = votes + 1 WHERE candidate_id=?"
                );
                votePs.setInt(1, cid);
                votePs.executeUpdate();

                PreparedStatement updateUser = con.prepareStatement(
                    "UPDATE users SET has_voted = true WHERE username=?"
                );
                updateUser.setString(1, username);
                updateUser.executeUpdate();

                System.out.println("Vote Cast Successfully!");

            } else {
                System.out.println("Invalid Login!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
	