package online_voting;

import java.util.Scanner;

public class OnlineUtil {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nONLINE VOTING SYSTEM");
            System.out.println("1. Register");
            System.out.println("2. Vote");
            System.out.println("3. View Results");
            System.out.println("4. Exit");

            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1: Register.registerUser(); break;
                case 2: Vote.vote(); break;
                case 3: Result.viewResults(); break;
                case 4: System.exit(0);
                default: System.out.println("Invalid Choice!");
            }
        }
    }
}
