package railway_reservation_system;

import java.sql.*;
import java.util.Scanner;

public class RailwayReservationSystem {

    static Connection con = DBConnection.getConnection();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        while (true) {
            System.out.println("\n--- RAILWAY RESERVATION SYSTEM ---");
            System.out.println("1. View Trains");
            System.out.println("2. Book Ticket");
            System.out.println("3. Cancel Ticket");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1 -> viewTrains();
                case 2 -> bookTicket();
                case 3 -> cancelTicket();
                case 4 -> {
                    System.out.println("Thank You!");
                    System.exit(0);
                }
                default -> System.out.println("Invalid Choice!");
            }
        }
    }

    // VIEW TRAINS
    static void viewTrains() {
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM trains");

            System.out.println("\nID | NAME | SOURCE | DESTINATION | SEATS");
            while (rs.next()) {
                System.out.println(
                        rs.getInt(1) + " | " +
                        rs.getString(2) + " | " +
                        rs.getString(3) + " | " +
                        rs.getString(4) + " | " +
                        rs.getInt(5)
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // BOOK TICKET
    static void bookTicket() {
        try {
            System.out.print("Enter Passenger Name: ");
            sc.nextLine();
            String name = sc.nextLine();

            System.out.print("Enter Train ID: ");
            int trainId = sc.nextInt();

            PreparedStatement ps1 = con.prepareStatement(
                    "SELECT seats FROM trains WHERE train_id=?"
            );
            ps1.setInt(1, trainId);
            ResultSet rs = ps1.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                PreparedStatement ps2 = con.prepareStatement(
                        "INSERT INTO reservations(passenger_name, train_id) VALUES (?, ?)"
                );
                ps2.setString(1, name);
                ps2.setInt(2, trainId);
                ps2.executeUpdate();

                PreparedStatement ps3 = con.prepareStatement(
                        "UPDATE trains SET seats = seats - 1 WHERE train_id=?"
                );
                ps3.setInt(1, trainId);
                ps3.executeUpdate();

                System.out.println("Ticket Booked Successfully!");
            } else {
                System.out.println("No Seats Available!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CANCEL TICKET
    static void cancelTicket() {
        try {
            System.out.print("Enter PNR Number: ");
            int pnr = sc.nextInt();

            PreparedStatement ps1 = con.prepareStatement(
                    "SELECT train_id FROM reservations WHERE pnr=?"
            );
            ps1.setInt(1, pnr);
            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {
                int trainId = rs.getInt(1);

                PreparedStatement ps2 = con.prepareStatement(
                        "DELETE FROM reservations WHERE pnr=?"
                );
                ps2.setInt(1, pnr);
                ps2.executeUpdate();

                PreparedStatement ps3 = con.prepareStatement(
                        "UPDATE trains SET seats = seats + 1 WHERE train_id=?"
                );
                ps3.setInt(1, trainId);
                ps3.executeUpdate();

                System.out.println("Ticket Cancelled Successfully!");
            } else {
                System.out.println("Invalid PNR!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
