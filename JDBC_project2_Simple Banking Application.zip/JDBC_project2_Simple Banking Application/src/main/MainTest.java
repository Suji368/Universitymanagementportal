package main;

import uicontroller.BankController;

public class MainTest {

    public static void main(String[] args) {

        BankController controller = new BankController();

        controller.start();
    }
}