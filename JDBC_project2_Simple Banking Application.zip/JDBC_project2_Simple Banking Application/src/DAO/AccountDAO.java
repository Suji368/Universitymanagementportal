package DAO;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;

import DBConnection.DBConnection;
import model.Account;

	public class AccountDAO {

	    public void createAccount(Account account) {

	        try {

	            Connection conn = DBConnection.getConnection();

	            String sql = "INSERT INTO account(name,balance) VALUES(?,?)";

	            PreparedStatement ps = conn.prepareStatement(sql);

	            ps.setString(1, account.getName());
	            ps.setDouble(2, account.getBalance());

	            ps.executeUpdate();

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public void deposit(int id, double amount) {

	        try {

	            Connection conn = DBConnection.getConnection();

	            String sql = "UPDATE account SET balance = balance + ? WHERE id=?";

	            PreparedStatement ps = conn.prepareStatement(sql);

	            ps.setDouble(1, amount);
	            ps.setInt(2, id);

	            ps.executeUpdate();

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public void withdraw(int id, double amount) {

	        try {

	            Connection conn = DBConnection.getConnection();

	            String sql = "UPDATE account SET balance = balance - ? WHERE id=?";

	            PreparedStatement ps = conn.prepareStatement(sql);

	            ps.setDouble(1, amount);
	            ps.setInt(2, id);

	            ps.executeUpdate();

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public Account getAccount(int id) {

	        Account acc = null;

	        try {

	            Connection conn = DBConnection.getConnection();

	            String sql = "SELECT * FROM account WHERE id=?";

	            PreparedStatement ps = conn.prepareStatement(sql);

	            ps.setInt(1, id);

	            ResultSet rs = ps.executeQuery();

	            if (rs.next()) {

	                acc = new Account(
	                        rs.getInt("id"),
	                        rs.getString("name"),
	                        rs.getDouble("balance")
	                );
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return acc;
	    }
	}

