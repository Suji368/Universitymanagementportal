package uicontroller;

	import service.AccountService;

	import java.util.Scanner;

	public class BankController {

	    public void start() {

	        Scanner sc = new Scanner(System.in);

	        AccountService service = new AccountService();

	        while (true) {

	            System.out.println("\n--- Banking System ---");
	            System.out.println("1 Create Account");
	            System.out.println("2 Deposit");
	            System.out.println("3 Withdraw");
	            System.out.println("4 Check Balance");
	            System.out.println("5 Exit");

	            System.out.print("Enter choice: ");

	            int choice = sc.nextInt();

	            switch (choice) {

	                case 1:

	                    System.out.print("Enter Name: ");
	                    String name = sc.next();

	                    System.out.print("Enter Initial Balance: ");
	                    double bal = sc.nextDouble();

	                    service.createAccount(name, bal);

	                    break;

	                case 2:

	                    System.out.print("Enter Account ID: ");
	                    int id1 = sc.nextInt();

	                    System.out.print("Enter Amount: ");
	                    double dep = sc.nextDouble();

	                    service.deposit(id1, dep);

	                    break;

	                case 3:

	                    System.out.print("Enter Account ID: ");
	                    int id2 = sc.nextInt();

	                    System.out.print("Enter Amount: ");
	                    double wit = sc.nextDouble();

	                    service.withdraw(id2, wit);

	                    break;

	                case 4:

	                    System.out.print("Enter Account ID: ");
	                    int id3 = sc.nextInt();

	                    service.checkBalance(id3);

	                    break;

	                case 5:

	                    System.out.println("Thank you");
	                    System.exit(0);
	            }
	        }
	    }
	}
