package service;

import DAO.AccountDAO;
import model.Account;

public class AccountService {
	
	    AccountDAO dao = new AccountDAO();

	    public void createAccount(String name, double balance) {

	        Account acc = new Account(name, balance);

	        dao.createAccount(acc);

	        System.out.println("Account Created Successfully");
	    }

	    public void deposit(int id, double amount) {

	        dao.deposit(id, amount);

	        System.out.println("Deposit Successful");
	    }

	    public void withdraw(int id, double amount) {

	        dao.withdraw(id, amount);

	        System.out.println("Withdraw Successful");
	    }

	    public void checkBalance(int id) {

	        Account acc = dao.getAccount(id);

	        if (acc != null) {

	            System.out.println("Account ID : " + acc.getId());
	            System.out.println("Name : " + acc.getName());
	            System.out.println("Balance : " + acc.getBalance());

	        } else {

	            System.out.println("Account not found");

	        }
	    }
	}

