package rental_vehicle_model;

public class Vehicle {
    private int id;
    private String name;
    private String type;
    private double price;
    private String status;

    public Vehicle() {}

    public Vehicle(String name, String type, double price, String status) {
        this.name = name;
        this.type = type;
        this.price = price;
        this.status = status;
    }

    public Vehicle(int id, String name, String type, double price, String status) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.price = price;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}