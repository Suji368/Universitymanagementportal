package UIController;

import java.util.Scanner;

import rental_vehicle_service.VehicleService;

public class VehicleController {

    public void start() {

        Scanner sc = new Scanner(System.in);

        VehicleService service = new VehicleService();

        while (true) {

            System.out.println("\n--- Vehicle Rental System ---");
            System.out.println("1 Add Vehicle");
            System.out.println("2 View Vehicles");
            System.out.println("3 Rent Vehicle");
            System.out.println("4 Return Vehicle");
            System.out.println("5 Exit");

            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {

                case 1:
                	
                    System.out.print("Enter Vehicle Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Vehicle Type: ");
                    String type = sc.nextLine();

                    System.out.print("Enter Price Per Day: ");
                    double price = sc.nextDouble();

                    service.addVehicle(name, type, price);

                    break;

                case 2:

                    service.viewVehicles();

                    break;

                case 3:

                    System.out.print("Enter Vehicle ID: ");
                    int rentId = sc.nextInt();

                    service.rentVehicle(rentId);

                    break;

                case 4:

                    System.out.print("Enter Vehicle ID: ");
                    int returnId = sc.nextInt();

                    service.returnVehicle(returnId);

                    break;

                case 5:

                    System.out.println("Thank you");
                    System.exit(0);
            }
        }
    }
}