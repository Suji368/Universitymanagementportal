package rental_vehicle_service;

import rental_vehicle_dao.VehicleDAO;
import rental_vehicle_model.Vehicle;

public class VehicleService {

    VehicleDAO dao = new VehicleDAO();

    public void addVehicle(String name, String type, double price) {

        Vehicle vehicle = new Vehicle(name, type, price, "Available");

        dao.addVehicle(vehicle);

        System.out.println("Vehicle Added Successfully");
    }

    public void rentVehicle(int id) {

        dao.rentVehicle(id);

        System.out.println("Vehicle Rented Successfully");
    }

    public void returnVehicle(int id) {

        dao.returnVehicle(id);

        System.out.println("Vehicle Returned Successfully");
    }

    public void viewVehicles() {

        dao.viewVehicles();
    }
}