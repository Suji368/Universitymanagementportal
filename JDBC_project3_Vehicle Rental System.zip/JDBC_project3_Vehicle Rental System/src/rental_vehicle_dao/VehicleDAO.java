package rental_vehicle_dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import DBConnection.DBConnection;
import rental_vehicle_model.Vehicle;

public class VehicleDAO {

    public void addVehicle(Vehicle vehicle) {

        try {

            Connection conn = DBConnection.getConnection();

            String sql = "INSERT INTO vehicle(name,type,price,status) VALUES(?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, vehicle.getName());
            ps.setString(2, vehicle.getType());
            ps.setDouble(3, vehicle.getPrice());
            ps.setString(4, vehicle.getStatus());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void rentVehicle(int id) {

        try {

            Connection conn = DBConnection.getConnection();

            String sql = "UPDATE vehicle SET status='Rented' WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void returnVehicle(int id) {

        try {

            Connection conn = DBConnection.getConnection();

            String sql = "UPDATE vehicle SET status='Available' WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewVehicles() {

        try {

            Connection conn = DBConnection.getConnection();

            String sql = "SELECT * FROM vehicle";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                System.out.println(
                        rs.getInt("id") + " | " +
                        rs.getString("name") + " | " +
                        rs.getString("type") + " | " +
                        rs.getDouble("price") + " | " +
                        rs.getString("status")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}