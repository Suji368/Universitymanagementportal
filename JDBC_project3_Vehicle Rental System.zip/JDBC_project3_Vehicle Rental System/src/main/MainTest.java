package main;

import UIController.VehicleController;

public class MainTest {

    public static void main(String[] args) {

        VehicleController controller = new VehicleController();

        controller.start();
    }
}